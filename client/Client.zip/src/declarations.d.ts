declare module '*.jpg';
declare module '*.png';
declare module '*.jpeg';
declare module '*.svg';

declare module '*.tsx' {
  const content: any;
  export default content;
}
