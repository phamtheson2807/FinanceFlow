declare module '*.mp4' {
    const src: string;
    export default src;
}

declare module '*.gif' {
    const src: string;
    export default src;
} 